import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        // <data type> +  <name>
//        string Name = "Minh Hiếu";
//        int age = 21 ;
        // ten bien khong duoc bat dau bang so
        // khong trung voi cac keyword trong lap trinh : while , if , ...
        // trong bien se phan biet chu hoa va chu thuong
        // bien se duoc dat theo chuan camel - case
        //vi du :  string myEmail = "minhhieu@mail";
//        systerm.out.println("My name is" + Name);
//        systerm.out.println("My age is" + age);
        Scanner scanner = new Scanner(System.in);
//        System.out.println("moi nhap so : ");
//        int number = scanner.nextInt();
//        System.out.printf("so vua nhap la :  %d" , number);
        System.out.printf("moi nhap ho ten : ");
        String name = scanner.nextline();
        System.out.println("your name is " + name);
    }
}