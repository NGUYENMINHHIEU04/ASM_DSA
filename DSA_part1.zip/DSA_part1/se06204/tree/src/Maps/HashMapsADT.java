package Maps;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class HashMapsADT {
    public void createMap(){
        Map<String , String> animals = new HashMap<>();
        animals.put("Tiger" , "Cat");
        animals.put("Manh" , "Dog");
        animals.put("Cho" , "Cun");
        animals.put("Trau" , "Bo");
        System.out.println("Hashmap : " +animals);
    }
    public void createMapV2(){
        Map<String , Integer> languages = new LinkedHashMap<>();
        languages.put("Python" , 1);
        languages.put("Java" , 2);
        languages.put("C#" , 3);
        languages.put("Dark" , 4);
        System.out.println("Language number : " +languages);
    }
    public void createMapV3(){
        Map<Integer , Integer> numbers = new TreeMap<>();
        numbers .put(100, 1);
        numbers .put(200, 2);
        numbers .put(10, 3);
        numbers .put(20, 4);
        System.out.println("Number : " +numbers );
    }


}
