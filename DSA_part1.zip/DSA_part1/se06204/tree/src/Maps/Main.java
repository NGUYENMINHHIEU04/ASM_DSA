package Maps;

import java.util.LinkedHashMap;

public class Main {
    public static void main (String[] args){
        HashMapsADT Map = new HashMapsADT();
        Map.createMap();
        Map.createMapV2();
        Map.createMapV3();
    }
}
