package ImprovedSecurity;

public class Main {
    public static void main(String[] args) {
        // Create a new user account
        UserAccount user = new UserAccount("john_doe", "SecurePass123");

        // Attempt to authenticate with the correct password
        if (user.authenticate("SecurePass123")) {
            System.out.println("Authentication successful!");
        } else {
            System.out.println("Authentication failed.");
        }

        // Attempt to change the password
        try {
            user.setPassword("NewSecurePass456");
            System.out.println("Password changed successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println("Password change failed: " + e.getMessage());
        }

        // Attempt to authenticate with the new password
        if (user.authenticate("NewSecurePass456")) {
            System.out.println("Authentication successful with new password!");
        } else {
            System.out.println("Authentication failed with new password.");
        }

        // Attempt to authenticate with an incorrect password
        if (user.authenticate("WrongPassword")) {
            System.out.println("Authentication successful!");
        } else {
            System.out.println("Authentication failed with wrong password.");
        }
    }
}
