package ImprovedSecurity;


    public class UserAccount {
        private String username; // Private variable, cannot be accessed directly
        private String password; // Private variable, sensitive information

        public UserAccount(String username, String password) {
            this.username = username;
            setPassword(password); // Using setter to enforce validation
        }

        // Public method to set a new password with validation
        public void setPassword(String newPassword) {
            if (isValidPassword(newPassword)) {
                this.password = newPassword;
            } else {
                throw new IllegalArgumentException("Invalid password.");
            }
        }

        // Public method to authenticate user
        public boolean authenticate(String passwordAttempt) {
            return this.password.equals(passwordAttempt); // Safe comparison
        }

        // Private method to validate password strength
        private boolean isValidPassword(String password) {
            // Implement password validation logic (e.g., length, complexity)
            return password.length() >= 8; // Simple example
        }
    }

