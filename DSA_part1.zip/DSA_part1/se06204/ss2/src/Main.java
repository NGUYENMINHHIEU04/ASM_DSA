import java.util.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
//        Shapes rec = new shinhchunhat(4,5);
//        double area = rec.caculateArea();
//        System.out.println("dien tich hinh chu nhat la : " + area);
//        double peri = rec.caculatePeri();
//        System.out.println("Chu vi hinh chu nhat la : " + peri);
//
//
//        Shapes sq = new Svuong(4,4);
//        double area2 = sq.caculateArea();
//        System.out.println("dien tich hinh vuong la : " + area2);
//        double peri2 = sq.caculatePeri();
//        System.out.println("Chu vi hinh vuong la : " + peri2 );
//
//
//
//
//        Produccontroler product = new Produccontroler(null);
//        // can truy cap vao thuoc tinh myname va age trong productcontroler lam ntn
//        String name = Produccontroler.myName;
//        System.out.println( "ten la : " + name );

//        Produccontroler.showage();
////        Produccontroler.showage();
////        Produccontroler.showage();
//
//        int age = Produccontroler.age;
//        System.out.println( "tuoi la : " + age );
//
//        arraybase arr = new arraybase();
//        //arr.showarray();
//
//        int []radNumber = {3,4,1,9,5,10,2,99,14};
//
//        int max =arr.maxNumberInArray(radNumber);
//        System.out.println("Max number is : " + max);
//
//        int min =arr.minNumberInArray( radNumber);
//        System.out.println("Min number is : " + min);
//
//        int sum = arr.sumNumberInArr(radNumber);
//        System.out.println("Tong cac so nguyen to la  : " + sum);
//
//        double avg = arr.avgNumber(radNumber);
//        System.out.println("Tbc cac so nguyen to la  : " + avg);

        ///////////////////////////////////////////////////////////

        LinkListADT ListADT = new LinkListADT();
        ListADT.createLinkedList();
        List<String> data = ListADT.createLinkedList();
        ListADT.addElement(data);
        ListADT.addElementByIndex(data , 2 , "Lion");
        ListADT.getElementByIndex(data,3);
        ListADT.changeDataElement(data, 2,"Chihuahua");

        ListADT.removeDataElement(data,3);



        ListADT.findData(data , "Chihuahua");
        ListADT.findElementV1(data , "Manhcon");
        ListADT.findElementV2(data , "Manhcon");
        ListADT.loopElement(data);




        //////////////////////////////////////////////////////////

        StackADT stack = new StackADT();
        Stack<Integer> dataNumber = stack.createStack();
        stack.displayStack(dataNumber);
        stack.removeElement(dataNumber);
        stack.peekElement(dataNumber);
        stack.TestStackFull(dataNumber);
        stack.countElement(dataNumber);
        stack.findElement(dataNumber,2);
        stack.checkStack(dataNumber);


        ////////////////////////////////////////////////////////////



        ////////////////////////////////////////////////////////////

        QueueADT queueADT = new QueueADT();
        Queue<String> colors = queueADT.createQueue();
        queueADT.inserDataQueue(colors);
        queueADT.showQueue(colors);
        queueADT.checkSizeQueue(colors);
        queueADT.getelementQueue(colors);
        queueADT.getelementQueueV2(colors);
        queueADT.showQueue(colors);
        queueADT.removeElement(colors);
        queueADT.removeElementV2(colors);
        queueADT.showQueue1(colors);
        queueADT.loopElement(colors);
        queueADT.addToQueue(colors, "green");
        queueADT.checkQueueEmpty(colors);

        ///////////////////////////////////////////////////
        ArrayListADT arrayListADT = new ArrayListADT();
        List<String> food = arrayListADT.createArrayList();
        arrayListADT.showArrayList(food);
        arrayListADT.chageElement(food,2,"chim thui");
        arrayListADT.getaElement(food,2);
        arrayListADT.getSizeArrayList(food);
        arrayListADT.removeArrayList(food,2);
        arrayListADT.loopElementArrayList(food);


        ///////////////////////////
        Student st1 = new Student("BH00412" , "Nguyen Tien Manh" , 20 , "Hanoi");
        Student st2 = new Student("BH07412" , "Bat That Bai" , 21 , "Hanoi");
        Student st3 = new Student("BH80412" , "Nguyen Tien Cung" , 20 , "Hanoi");
        Student st4 = new Student("BH00512" , "Pham Khac Manh" , 24 , "Hanoi");
        ArrayList<Student> dataST = new ArrayList<>();
        StudentArrayList studentArrayList = new StudentArrayList();
        studentArrayList.createDataStudent(st1 , dataST);
        studentArrayList.createDataStudent(st2 , dataST);
        studentArrayList.createDataStudent(st3 , dataST);
        studentArrayList.createDataStudent(st4 , dataST);

        boolean CheckingST = studentArrayList.findStudent(dataST,"BH00840");
        if (CheckingST){
            System.out.println("Found");
        } else {
            System.out.println("Not found");
        }
//        studentArrayList.updateNameStudentbyID(dataST,"BH07412","Nguyen Tien Manh");
//        studentArrayList.showInforStudent(dataST);
//        studentArrayList.deleteNameStudentbyID(dataST,"BH00412");
//        studentArrayList.showInforStudent(dataST);







    }


         ////////////////////////////////////////////////////////////
    }
