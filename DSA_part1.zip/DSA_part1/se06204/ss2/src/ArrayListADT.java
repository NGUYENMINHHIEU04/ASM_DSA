import java.util.ArrayList;
import java.util.List;


    public class ArrayListADT {

        public List<String> createArrayList() {
            List<String> food = new ArrayList<>();
            // ArrayList<String> fruit = new ArrayList<>();
            food.add("Cua hoang de");
            food.add("Chim bay day troi");
            food.add("Tom alaska");
            return food;
        }
        public void showArrayList(List<String> myArrayList){
            System.out.println("Array list : " + myArrayList);
        }


        public void getaElement(List<String> list , int index) {
            String data = list.get(index); // truy cap vao phan tu
            System.out.println("Element : " + data);
        }

        public void chageElement(List<String> list , int index , String value) {
            list.set(index,value);
            showArrayList(list);
        }
        public void getSizeArrayList (List<String> list){
            int size = list.size();
            System.out.println("Size of arraylist is : " + size);
        }
        public void removeArrayList (List<String> list , int index){
            list.remove(index);
            showArrayList(list);
        }

        public void loopElementArrayList(List<String> list){
            for (int i = 0; i < list.size() ; i++ ){
                System.out.println("Iterm : " + list.get(i));
            }
            for (String data : list){
                System.out.println("Data : " + data);
            }
        }

}
