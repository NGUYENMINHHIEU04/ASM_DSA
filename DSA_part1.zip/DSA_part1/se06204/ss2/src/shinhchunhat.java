public class shinhchunhat extends Shapes {
    public shinhchunhat (double a , double b ){
        height = a ;
        width = b ;
    }
    @Override
    public double caculateArea() {
        return height * width;
    }
    public double caculatePeri() {
        return (height + width) * 2;
    }
}
