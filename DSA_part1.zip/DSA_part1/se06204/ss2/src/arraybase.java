public class arraybase {
    public void  showarray(){
        // khai bao mang
        // khai bao don gian
        int [] numbers = {1,2,3,4,5,6,7,8,9};
        // khai bao chi can biet so luong ptu ; khong can bieet ro gia tri cua tu ptu trong mang
        int [] mynumber = new int [4];
        // khi khai bao mang phai luon luon biet kich thuoc cuar mang [ kich thuoc luon co dinh kh doi ]
        //truy cap vao mot ptu trong mang
        int n = numbers [6];
        System.out.println(n);

        // duyet qua tat ca cac phan tu nam trong mang
        // 1 - for
        int lengthArr = numbers.length;
        for (int i = 0 ; i < lengthArr ; i++ ){
            double x = numbers[i] ;
            System.out.println("value = "  + numbers[i]);
        };

        for(double j : numbers) {
            System.out.println("value = "  + j );
        };

        int k = 0;
        while(k < numbers.length) {
            double x = numbers[k] ; k++;
            System.out.println("value = "  + k );
        }

        int l = 0;
        do {
            System.out.println("Gia tri phan tu l la " + numbers[l]);
            l++;
        } while (l < lengthArr);




    }

    public int maxNumberInArray(int [] numbers) {
        int max = numbers[0] ; // lay ra ptu dau tien gia su nos laf ptu lon nhat
        for (int i = 1 ; i < numbers.length ; i++)
        {
            if (numbers[i] > max ) {
                max = numbers[i];
            }
        }
        return max;
    }

    public int minNumberInArray(int [] numbers) {
        int min = numbers[0] ; // lay ra ptu dau tien gia su no la ptu nho nhat
        for (int a = 1 ; a < numbers.length ; a++)
        {
            if (numbers[a] < min ) {
                min = numbers[a];
            }
        }
        return min;
    }

    private boolean checkingNumber (int num) {
        if (num <0)
        {
            return false;
        }if (num == 2) {
        return true;
        }
        for ( int i = 2 ; i <= Math.sqrt(num) ; i ++ ){
            if (num % i == 0){
                return false;
            }
        }
        return true;
    }

    public int sumNumberInArr (int[] arrNumber){
        int sum = 0;
        for (int number : arrNumber){
            if (checkingNumber(number)){
                sum += number;
            }
        }
        return sum ;
    }
    public int countNum (int [] arrNumber){
        int count = 0 ;
        for ( int number :  arrNumber ){
            if (checkingNumber(number)){
                count ++ ;
            }
        }
        return count ;
    }

    public double avgNumber (int [] arrNumber){
        return (double) sumNumberInArr(arrNumber) / countNum(arrNumber);
    }
}

