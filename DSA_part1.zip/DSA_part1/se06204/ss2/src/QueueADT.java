import java.util.LinkedList;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueADT {
    public Queue<String> createQueue(){
        Queue<String> colors = new LinkedList<>();
        colors.add ("red");
        colors.add("blue");
        colors.add("blue");
        colors.add("blue");
        colors.add("blue");
        return colors;
    }
    public void showQueue(Queue<String> myQueue){
        System.out.println("Queue : " + myQueue);
    }
    public void inserDataQueue (Queue<String> queue){
        queue.offer("while");
        queue.offer("yellow");
        queue.offer("black");
    }

    public void checkQueueEmpty(Queue<String> queue) {
        boolean check = queue.isEmpty();
        if (check) {
            System.out.println("Queue is empty");
        } else {
            System.out.println("Queue is not empty");
        }
    }




    public void checkSizeQueue (Queue<String>queue){
        int size = queue.size(); // kich thuoc cua queue
        System.out.println("Size of queue : " + size);
    }


    public boolean isQueueFull (Queue<String>queue){
        if (queue.size() == 10 ){
            return true;
        }
        else {
            return false;
        }
    }
    public void addToQueue(Queue<String> queue, String element) {
        // Kiểm tra xem hàng đợi có đầy không
        if (isQueueFull(queue)) {
            System.out.println("Queue is full");
        } else {
            // Thêm phần tử vào hàng đợi
            queue.offer(element);
            System.out.println("Added " + element + " to queue");
        }
    }


    // ham element
    public void getelementQueue(Queue<String> queue){
        String element = queue.element();
        System.out.println("Data element : " + element);
    }
    // neu queue rong , ham element se tra ve loi
    ///////////////////////////////////////////////////////////////////////////
    // ham data
    public void getelementQueueV2(Queue<String> queue){
        String data = queue.peek();
        System.out.println("Data : " + data);
    }
    // neu queue la rong , ham data se tra ve null


    ///////////////////////////////////////////////////////////////////////////////
    public void removeElement(Queue<String> queue){
        String data = queue.remove();
        // neu queue rong , remove se bao loi
        System.out.println("Element remove : " + data);
    }

    public void removeElementV2(Queue<String> queue){
        String data = queue.poll();
        // neu queue rong , poll se tra ve null
        System.out.println("Element remove : " + data);
    }
    public void showQueue1(Queue<String> myQueue){
        System.out.println("Queue after reomove : " + myQueue);
    }




    public void loopElement(Queue<String> queue){
        for (String iterm : queue){
            System.out.println("Data iterm : " + iterm);
        }
    }
}
