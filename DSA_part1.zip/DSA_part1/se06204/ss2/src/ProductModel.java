public class ProductModel implements iQueryDatabase{
    public ProductModel (String conn) {

    }
    public final void test() {
        // cam class con overwrite lai phuong thuc nay
    }
    @Override
    public String getConnection() {
        return connection;
    }

    @Override
    public String getDisconnection() {
        return "";
    }

    @Override
    public void inserData() {

    }

    @Override
    public void updataData(int id) {

    }

    @Override
    public void deleteData(int id) {

    }
}
