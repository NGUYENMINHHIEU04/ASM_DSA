package stackinarrandlinklist;

public class Main {
    public static void main(String[] args) {
        StackUsingArray stack = new StackUsingArray(5);
        stack.push(10);
        stack.push(20);
        System.out.println("Top element: " + stack.peek());
        stack.pop();
        System.out.println("Top element after pop: " + stack.peek());


        StackUsingLinkedList stack1 = new StackUsingLinkedList();
        stack1.push(15);
        stack1.push(25);
        System.out.println("Top element: " + stack1.peek());
        stack1.pop();
        System.out.println("Top element after pop: " + stack1.peek());
    }
}
