package stackinarrandlinklist;
class StackUsingLinkedList {
    private class Node {
        int data;
        Node next;

        // Node constructor
        public Node(int data) {
            this.data = data;
            this.next = null;
        }
    }
    private Node top;
    // Constructor
    public StackUsingLinkedList() {
        this.top = null; // Initialize top as null
    }
    // Push element onto the stack
    public void push(int value) {
        Node newNode = new Node(value);
        newNode.next = top;
        top = newNode;
    }
    // Pop element from the stack
    public int pop() {
        if (top == null) {
            System.out.println("Stack Underflow");
            return -1; // Return a sentinel value for underflow
        }
        int poppedValue = top.data;
        top = top.next;
        return poppedValue;
    }
    // Peek at the top element of the stack
    public int peek() {
        if (top == null) {
            System.out.println("Stack is empty");
            return -1;
        }
        return top.data;
    }
    // Check if the stack is empty
    public boolean isEmpty() {
        return top == null;
    }
}

