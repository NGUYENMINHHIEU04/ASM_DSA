package RecursionAlogorithms;

public class Recursion {
    public static void countNumber(int number){
        if (number<0)
        {
            return;
        }
        for (int i = 1 ; i <= number ; i++){
            System.out.println(i);
        }
    }

    public static void countNum(int n,int m){
        if(n>m){
            return;
        }
        System.out.println(n);
        n=n+1;
        countNum(n,m);
    }

    public static long factorialNonRecursion (int n){
        if (n<0){
            return 0;
        }
        if (n==1 || n==0){
            return 1;
        }
        return n * factorialNonRecursion(n-1);
    }


    public static long fibonacciRecursion (long num){
        if (num == 1 || num == 2){
            return 1;
        }
        return fibonacciRecursion(num - 1) + fibonacciRecursion(num - 2);
    }


    public static long sumNum (long n){
        if (n <= 1){
            return 1;
        }
        return sumNum((n*(n-1)) / 2);
    }
    public static long sumNonRecursionNum(long n){
        return ((n*(n-1)) / 2);
    }
}
