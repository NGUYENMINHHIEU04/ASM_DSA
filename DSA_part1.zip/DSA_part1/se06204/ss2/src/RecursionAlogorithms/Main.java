package RecursionAlogorithms;

public class Main {
    public static void main (String[]args){
        Recursion.countNumber(8);
        Recursion.countNum(1,9);
        long result = Recursion.factorialNonRecursion(5);
        System.out.println("Rrecursion of 5 is : " + result);
        for ( int i = 1 ; i <= 20 ; i++){
            System.out.println(Recursion.fibonacciRecursion(i));
        }
        long sum = Recursion.sumNum(100);
        System.out.println("tong tu 1-10 la : " + sum);

    }


}
