package Implementation_of_FIFO_Queue;
import java.util.LinkedList;

public class FIFOQueue<T> {
    private LinkedList<T> queue;

    // Constructor to initialize the queue
    public FIFOQueue() {
        queue = new LinkedList<>();
    }

    // Method to add an element to the queue
    public void enqueue(T element) {
        queue.addLast(element);
        System.out.println("Enqueued: " + element);
    }

    // Method to remove and return the first element from the queue
    public T dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is empty. Cannot dequeue.");
            return null;
        }
        T element = queue.removeFirst();
        System.out.println("Dequeued: " + element);
        return element;
    }

    // Method to check if the queue is empty
    public boolean isEmpty() {
        return queue.isEmpty();
    }

    // Method to get the size of the queue
    public int size() {
        return queue.size();
    }

    // Main method to demonstrate the FIFO queue
    public static void main(String[] args) {
        FIFOQueue<String> ticketQueue = new FIFOQueue<>();

        // Enqueue customers
        ticketQueue.enqueue("Customer A");
        ticketQueue.enqueue("Customer B");
        ticketQueue.enqueue("Customer C");

        // Dequeue customers
        ticketQueue.dequeue(); // Should serve Customer A
        ticketQueue.dequeue(); // Should serve Customer B
        ticketQueue.dequeue(); // Should serve Customer C

        // Try to dequeue from an empty queue
        ticketQueue.dequeue(); // Should indicate that the queue is empty
    }
}

