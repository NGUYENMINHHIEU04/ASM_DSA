public class Svuong extends Shapes{
    public Svuong (double a , double b){
        width = b;
        height = a;
    }
    @Override
    public double caculateArea() {
        return height * height;
    }
    public double caculatePeri() {
        return height * 4;
    }
}
