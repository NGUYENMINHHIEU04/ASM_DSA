package SortingAlogorithms;

public class SelectionSort {
    public void SelectionSort(int[]numbers){
        int size = numbers.length;
        for (int i = 0 ; i< size - 1 ; i ++ ){
            int minKey = i;
            for (int j = i+1 ; j< size  ; j ++){
                if (numbers[j] < numbers[minKey]){
                    minKey = j ;
                }
            }
            int tmp = numbers[i];
            numbers[i]=numbers[minKey];
            numbers[minKey]=tmp;
        }
    }
    public void showArray(int[]array){
        for(int i : array)
        {
            System.out.println(i);
        }
    }

}
