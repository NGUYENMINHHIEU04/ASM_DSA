package SortingAlogorithms;

import java.util.Arrays;

public class Main {
    public static void main (String [] args){
        BulbleShort bulbleShort = new BulbleShort();
        int [] randomNumber = {1,3,2,8,5,6,7,9,4};


//        bulbleShort.sorting(randomNumber);
//        bulbleShort.prinArray(randomNumber);

        Insertion insertion = new Insertion();
        Insertion.sorting(randomNumber);
        Insertion.showArray(randomNumber);
///////////////////////////////////////////////////////////
        int [] arr = {3,2,8,5,6,0,7,9,4};
        MergerSort merger = new MergerSort();
        merger.Merger(arr,0,arr.length -1);
        merger.showArray(arr);
/////////////////////////////////////////////////////////

        int[] data = { 8, 7, 2, 1, 0, 9, 6 };
        System.out.println("Unsorted Array");
        System.out.println(Arrays.toString(data));

        int size = data.length;

        // call quicksort() on array data

        QuickSort.quickSort(data, 0, size - 1);
        System.out.println("Sorted Array in Ascending Order: ");
        System.out.println(Arrays.toString(data));


        ////////////////////////

    }
}
