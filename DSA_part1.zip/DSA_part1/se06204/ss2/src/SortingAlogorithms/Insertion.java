package SortingAlogorithms;

public class Insertion {
    public static void sorting(int[] numbers){
        int size = numbers.length;
        for (int i = 0 ; i < size ; i ++ ) {
            int key =numbers[i];
            int j = i-1;
            while (j>=0 && key<numbers[j]){
                numbers[j+1] =  numbers[j];
                j--;
            }
            numbers[j+1]=key;
        }
    }
    public static void  showArray(int[] numbers) {
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("key = " + i + "; item : " + numbers[i]);
        }
    }
}
