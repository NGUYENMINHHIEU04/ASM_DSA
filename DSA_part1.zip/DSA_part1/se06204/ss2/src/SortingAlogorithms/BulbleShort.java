package SortingAlogorithms;

public class BulbleShort {
    public void sorting (int[] numbers ){
        int sizeArray = numbers.length; // kich  thuoc xep mang
        for (int i = 0 ; i< sizeArray-1 ; i++){
            for (int j = 0 ; j < sizeArray - i - 1 ; j++){
                if (numbers[j] > numbers[j+1]){
                    int tmp = numbers[j];
                    numbers[j] = numbers[j+1];
                    numbers[j+1] = tmp;
                }
            }
        }
    }
    public void prinArray (int[] numbers){
        for(int item: numbers){
            System.out.println(item);
        }
    }
}
