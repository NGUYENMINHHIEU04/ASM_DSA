package SortingAlogorithms;

public class MergerSort {
    public void Sorting (int [] arr , int p , int q , int r ) {
        // tinh so luong phan tu mang ben trai va phai
        int n1 = q - p + 1;// middle - left + 1
        int n2 = r - q ; // right - middle
        // tao mang trai va phai
        int [] L = new int [n1]; // tao bang co dinh so luong phan tu
        int [] R = new int[n2];
        // do phan tu vao mang trai phai
        for (int i = 0 ; i < n1 ; i++){
            L[i] = arr[p+i];
        }
        for(int j = 0 ; j  < n2 ; j++){
            R[j] = arr[q+1+j];
        }
        int i,j,k;
        i = 0; j = 0; k = p;
        while (i < n1 && j < n2){
            if(L[i] < R[j]){
                arr[k] = L[i];
                i++;
            }else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }
        while (i<n1){
            arr[k] = L[i];
            i++;
            k++;
        }
    }


    public void Merger (int [] arr , int left , int right ){
        // left vitri cac ptu mang ben trai
        // right vitri cac ptu ben phai
        if (left < right){
            int middle = (left + right) /2  ;
            // De quy goi lai ham trong chinh no

            Merger(arr , left , middle);// tinh mang trai
            Merger(arr , middle + 1  , right );// tinh mang phai
            // sau khi chia mang xong thi hop lai de sap xep
            Sorting(arr , left , middle , right);
        }
    }
    public void showArray(int[]array){
        for(int i : array){
            System.out.println(i);
        }
    }
}
