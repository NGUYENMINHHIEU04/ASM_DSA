public class car {
    // dinh nghia thuoc tinh
    public String name = " BMW ";
    private  int weight;
    protected  float money = 1000;

    public String start (){
        return this .name ;
    }

    // over loading
    public String start ( String place) {
        return place ;
    }

    public String stop (){
        return "My home";
    }


}
