public class Produccontroler extends ProductModel{
    public static String myName = "teo";
    public static int age = 19;
    public Produccontroler(String conn) {
        super(conn);
    }

//    public void test() {
//
//    }

    static {
        age += 10 ;
    }
    public static void showage(){
        age += 30 ;
    }
}
