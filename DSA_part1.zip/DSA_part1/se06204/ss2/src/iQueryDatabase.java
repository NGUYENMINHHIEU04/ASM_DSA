public interface iQueryDatabase extends Database
{
    public void inserData();
    public void updataData(int id);
    public void deleteData(int id);
}
