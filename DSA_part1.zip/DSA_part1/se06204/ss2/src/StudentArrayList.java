import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.jar.Attributes;

public class StudentArrayList {
    public void createDataStudent (Student student ,ArrayList<Student> arrayList){
        arrayList.add(student);
    }
    public boolean findStudent(ArrayList<Student> students , String id){
        for (Student student : students) {
            if (student.getId().equals(id)) {
                return true; // Trả về sinh viên tìm thấy
            }
        }
        return false; // Không tìm thấy sinh viên
    }
    public boolean updateNameStudentbyID (ArrayList<Student> students ,String id , String nameStudent){
        if (!findStudent(students,id)){
            return  false;
        }
        for (int i = 0 ; i < students.size() ; i++){
            if (students.get(i).getId().equals(id)){
                students.get(i).setName(nameStudent);
                return true;
            }
        }
        return false;
    }

    public boolean deleteNameStudentbyID (ArrayList<Student> students ,String id ){
        if (!findStudent(students,id)){
            return  false;
        }
        for (int i = 0 ; i < students.size() ; i++){
            if (students.get(i).getId().equals(id)){
                students.remove(i);
                return true;
            }
        }
        return false;
    }
    public void showInforStudent(ArrayList<Student> students){
        for (Student iterm : students){
            System.out.println("ID = "+ iterm.getId() + " name : " +iterm.getName());
        }
    }
}
