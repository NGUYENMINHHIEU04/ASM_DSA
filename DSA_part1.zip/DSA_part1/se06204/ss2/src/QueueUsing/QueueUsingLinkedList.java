package QueueUsing;

public class QueueUsingLinkedList {
    private class Node {
        int data;
        Node next;

        // Node constructor
        public Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    private Node front, rear;

    // Constructor
    public QueueUsingLinkedList() {
        front = rear = null; // Initialize front and rear as null
    }

    // Enqueue element to the queue
    public void enqueue(int value) {
        Node newNode = new Node(value);
        if (rear == null) {
            front = rear = newNode; // If queue is empty, both front and rear point to the new node
            return;
        }
        rear.next = newNode; // Link the old rear to the new node
        rear = newNode; // Update rear to the new node
    }

    // Dequeue element from the queue
    public int dequeue() {
        if (front == null) {
            System.out.println("Queue Underflow");
            return -1; // Return a sentinel value for underflow
        }
        int dequeuedValue = front.data;
        front = front.next; // Move front to the next node
        if (front == null) {
            rear = null; // If the queue is now empty, update rear to null
        }
        return dequeuedValue;
    }

    // Peek at the front element of the queue
    public int peek() {
        if (front == null) {
            System.out.println("Queue is empty");
            return -1;
        }
        return front.data;
    }

    // Check if the queue is empty
    public boolean isEmpty() {
        return front == null;
    }
}
