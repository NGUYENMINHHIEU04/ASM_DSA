package QueueUsing;

public class Main {
    public static void main(String[] args) {
        // Kiểm tra QueueUsingArray
        System.out.println("\nTesting Queue Using Array:");
        QueueUsingArray queueArray = new QueueUsingArray(5);
        queueArray.enqueue(10);
        queueArray.enqueue(20);
        queueArray.enqueue(30);
        System.out.println("Front element: " + queueArray.peek());
        System.out.println("Dequeued: " + queueArray.dequeue());
        System.out.println("Front element after dequeue: " + queueArray.peek());

        //Kiểm tra QueueUsingLinkedList
        System.out.println("\nTesting Queue Using Linked List:");
        QueueUsingLinkedList queueList = new QueueUsingLinkedList();
        queueList.enqueue(100);
        queueList.enqueue(200);
        queueList.enqueue(300);
        System.out.println("Front element: " + queueList.peek());
        System.out.println("Dequeued: " + queueList.dequeue());
        System.out.println("Front element after dequeue: " + queueList.peek());
    }
}
