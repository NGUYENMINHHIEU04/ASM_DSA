package QueueUsing;

public class QueueUsingArray {
    private int[] queue;
    private int front, rear, capacity, size;

    // Constructor
    public QueueUsingArray(int capacity) {
        this.capacity = capacity;
        queue = new int[capacity];
        front = 0;
        rear = -1;
        size = 0;
    }

    // Enqueue element to the queue
    public void enqueue(int value) {
        if (size == capacity) {
            System.out.println("Queue Overflow");
            return;
        }
        rear = (rear + 1) % capacity;
        queue[rear] = value;
        size++;
    }

    // Dequeue element from the queue
    public int dequeue() {
        if (size == 0) {
            System.out.println("Queue Underflow");
            return -1; // Return a sentinel value for underflow
        }
        int dequeuedValue = queue[front];
        front = (front + 1) % capacity;
        size--;
        return dequeuedValue;
    }

    // Peek at the front element of the queue
    public int peek() {
        if (size == 0) {
            System.out.println("Queue is empty");
            return -1;
        }
        return queue[front];
    }

    // Check if the queue is empty
    public boolean isEmpty() {
        return size == 0;
    }

    // Get the size of the queue
    public int size() {
        return size;
    }
}
